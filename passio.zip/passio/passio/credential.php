<?php 
	/*Update credentials*/
	define('EMAIL', 'info@passioarchitects.com');
	define('PASS', '0179363Raju**');
 ?>